﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;


namespace House_rent
{
    public partial class Rent : Form
    {
        public Rent()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database2.mdf"";Integrated Security=True");
        private void populate()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database2.mdf"";Integrated Security=True"))
                {
                    conn.Open();
                    string query = "select * from Rent";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    SqlCommandBuilder builder = new SqlCommandBuilder(da);
                    var ds = new DataSet();
                    da.Fill(ds);
                    //dataGridView2.DataSource = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm2 mainForm2 = new MainForm2();
            mainForm2.Show();
            this.Hide();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Hno.Text == "" || Custid.Text == "" || CustNu.Text == "" || RentFee.Text == "")
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "SELECT ISNULL(MAX(RentID), 0) + 1 FROM Rent";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    int nextRentId = Convert.ToInt32(cmd.ExecuteScalar());
                    RentId.Text = nextRentId.ToString();
                    query = "INSERT INTO Rent ([RentID], [House Number], [Customer ID], [Phone Number], [Rent FEE]) VALUES ('" + RentId.Text + "', '" + Hno.Text + "', '" + Custid.Text + "', '" + CustNu.Text + "', '" + RentFee.Text + "')";
                    cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show($"Successfully Added. Your Rent ID is: {RentId.Text}");
                    conn.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void Rent_Load(object sender, EventArgs e)
        {
            populate();
        }
    }
}
