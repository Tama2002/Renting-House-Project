﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_rent
{
    public partial class Total : Form
    {
        public Total()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database3.mdf"";Integrated Security=True");
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }

        private void carlb1_Click(object sender, EventArgs e)
        {

        }

        private void Total_Load(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                // Count of houses
                String queryhouse = "select Count(*) from [House]";
                SqlDataAdapter sda = new SqlDataAdapter(queryhouse, conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                houselb1.Text = dt.Rows[0][0].ToString();

               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
