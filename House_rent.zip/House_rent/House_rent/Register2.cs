﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_rent
{
    public partial class Register2 : Form
    {
        public Register2()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database1.mdf"";Integrated Security=True");

        private void populate()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database1.mdf"";Integrated Security=True"))
                {
                    conn.Open();
                    string query = "select * from Customer";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    SqlCommandBuilder builder = new SqlCommandBuilder(da);
                    var ds = new DataSet();
                    da.Fill(ds);
                    //dataGridView1.DataSource = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void btnBackToLogin_Click(object sender, EventArgs e)
        {

            if (!this.txtEmail.Text.Contains('@') || !this.txtEmail.Text.Contains('.'))
            {
                MessageBox.Show("Please Enter A Valid Email", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (txtPassword.Text != txtCPassword.Text)
            {
                MessageBox.Show("Password doesn't match!", "Error");
                return;
            }
            if (
                txtUsername.Text ==""||
                txtFName.Text == "" ||
                txtLName.Text == "" ||
                txtEmail.Text == "" ||
                txtPassword.Text == ""||
                txtCPassword.Text ==""
                )
            {
                MessageBox.Show("Fill the Box Properly!!");
            }
            else
            {
                if (!char.IsUpper(txtPassword.Text.First()))
                {
                    MessageBox.Show("Password must start with a capital letter and end with at least the last two symbols or digits !", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int passwordLength = txtPassword.Text.Length;
                if (passwordLength < 2 || !char.IsDigit(txtPassword.Text[passwordLength - 1]) || !char.IsDigit(txtPassword.Text[passwordLength - 2]))
                {
                    MessageBox.Show("Password must end with at least the last two symbols or digits ! ", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                try
                {
                    conn.Open();
                    string query = "insert into Customer (ID, FirstName, LastName, Email, Password, CPassword) values ('" + txtUsername.Text + "', '" + txtFName.Text + "', '" + txtLName.Text + "', '" + txtEmail.Text + "', '" + txtPassword.Text + "', '" + txtCPassword.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();

                    conn.Close();
                    populate();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    MessageBox.Show("Registration Sucessfully");
                }
                this.Hide();
                Login2 log2 = new Login2();
                log2.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login2 log2 = new Login2();
            log2.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Register2_Load(object sender, EventArgs e)
        {
            populate();
        }
    }
}
