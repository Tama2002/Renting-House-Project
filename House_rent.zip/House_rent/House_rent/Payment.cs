﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace House_rent
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database6.mdf"";Integrated Security=True");
        SqlConnection conn1 = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database3.mdf"";Integrated Security=True");

        private void StorePaymentInDatabase()
        {
            try
            {
                conn.Open();

                // Create SQL INSERT statement without @ symbols
                string insertQuery = "INSERT INTO Payment1 ([Customer ID], [Customer Name], [House Number], [Payment Method], [Rent]) " +
                                      "VALUES (@Customer_ID, @Customer_Name, @House_Number, @Payment_Method, @Rent)";

                using (SqlCommand cmd = new SqlCommand(insertQuery, conn))
                {
                    // Add parameters with @ symbols
                    cmd.Parameters.AddWithValue("@Customer_ID", CustID.Text);
                    cmd.Parameters.AddWithValue("@Customer_Name", CustName.Text);
                    cmd.Parameters.AddWithValue("@House_Number", CustNo.Text);
                    cmd.Parameters.AddWithValue("@Payment_Method", Method.Text);
                    cmd.Parameters.AddWithValue("@Rent", Rent.Text);

                    // Execute the INSERT statement
                    cmd.ExecuteNonQuery();
                }

                // Now open the second connection
                conn1.Open();

                string updateAvailabilityQuery = "UPDATE House SET Available = 'No' WHERE [House Number] = @House_Number";
                using (SqlCommand updateCmd = new SqlCommand(updateAvailabilityQuery, conn1))
                {
                    updateCmd.Parameters.AddWithValue("@House_Number", CustNo.Text);
                    updateCmd.ExecuteNonQuery();
                }

                MessageBox.Show("You Payment is Successfully Done .", "Thank You", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error storing payment information: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Close both connections in the finally block
                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                }

                if (conn1.State == System.Data.ConnectionState.Open)
                {
                    conn1.Close();
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            txtResult.Clear();
            txtResult.Text += "********************************************************************\n*";
            txtResult.Text += "**                                        Payment Receipt                       **\n*";
            txtResult.Text += "********************************************************************\n*";
            txtResult.Text += "Date : " + DateTime.Now + "\n\n";

            txtResult.Text += "Customer ID    : " + CustID.Text + "\n\n";
            txtResult.Text += "Customer Name  : " + CustName.Text + "\n\n";
            txtResult.Text += "House Number   : " + CustNo.Text + "\n\n";
            txtResult.Text += "Payment Method : " + Method.Text + "\n\n";
            txtResult.Text += "Rent Charge    : " + Rent.Text + "\n\n";

            txtResult.Text += "\n                                   Signature     ";


            StorePaymentInDatabase();


        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            CustID.Clear();
            CustName.Clear();
            CustNo.Clear();
            Rent.Clear();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(txtResult.Text, new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(10, 10));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm2 mainForm = new MainForm2();
            mainForm.Show();
            this.Hide();
        }

        private void Payment_Load(object sender, EventArgs e)
        {

        }
    }
}
