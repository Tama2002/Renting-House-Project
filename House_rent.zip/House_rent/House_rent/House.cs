﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;

namespace House_rent
{
    public partial class House : Form
    {
        public House()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database3.mdf"";Integrated Security=True");
        private void populate()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database3.mdf"";Integrated Security=True"))
                {
                    conn.Open();
                    string query = "select * from House";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    SqlCommandBuilder builder = new SqlCommandBuilder(da);
                    var ds = new DataSet();
                    da.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void House_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtNHouse.Text = dataGridView1.Rows[e.RowIndex].Cells["House Number"].Value.ToString();
            txtAddress.Text = dataGridView1.Rows[e.RowIndex].Cells["Address"].Value.ToString();
            txtNRoom.Text = dataGridView1.Rows[e.RowIndex].Cells["Number Of Rooms"].Value.ToString();
            txtNFloor.Text = dataGridView1.Rows[e.RowIndex].Cells["Number Of Floors"].Value.ToString();
            txtRent.Text = dataGridView1.Rows[e.RowIndex].Cells["Rent"].Value.ToString();
            txtACharge.Text = dataGridView1.Rows[e.RowIndex].Cells["Additional Charge"].Value.ToString();
            Choose.Text = dataGridView1.Rows[e.RowIndex].Cells["Available"].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
                txtNHouse.Text == "" ||
               txtAddress.Text == "" ||
               txtNRoom.Text == "" ||
               txtNFloor.Text == "" ||
               txtRent.Text == "" ||
               txtACharge.Text == "" 
               )
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into House ([House Number], Address, [Number Of Rooms], [Number Of Floors], Rent, [Additional Charge], Available) values ('" + txtNHouse.Text + "', '" + txtAddress.Text + "', '" + txtNRoom.Text + "', '" + txtNFloor.Text + "', '" + txtRent.Text + "', '" + txtACharge.Text + "', '" + Choose.SelectedItem.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("House Successfully Added");
                    conn.Close();
                    populate();



                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (
               txtNHouse.Text == "" ||
               txtAddress.Text == "" ||
               txtNRoom.Text == "" ||
               txtNFloor.Text == "" ||
               txtRent.Text == "" ||
               txtACharge.Text == "" 
               )
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "update House set Address = '" + txtAddress.Text + "', [Number Of Rooms] = '" + txtNRoom.Text + "', [Number Of Floors] = '" + txtNFloor.Text + "', [Rent] = '" + txtRent.Text + "', [Additional Charge] = '" + txtACharge.Text + "', Available = '" + Choose.SelectedItem.ToString() + "' where [House Number]= '" + txtNHouse.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully ");
                    conn.Close();
                    populate();



                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtNHouse.Text == "")
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from House where [House Number] ='" + txtNHouse.Text + " '; ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }

        private void Choose_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
