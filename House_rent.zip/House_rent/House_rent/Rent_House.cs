﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace House_rent
{
    public partial class Rent_House : Form
    {
        public Rent_House()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database2.mdf"";Integrated Security=True");
        private void populate()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database2.mdf"";Integrated Security=True"))
                {
                    conn.Open();
                    string query = "select * from Rent";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    SqlCommandBuilder builder = new SqlCommandBuilder(da);
                    var ds = new DataSet();
                    da.Fill(ds);
                    dataGridView2.DataSource = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Rent_House_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
             RentId.Text == "" ||
             Hno.Text == "" ||
             Custid.Text == "" ||
             CustNu.Text == "" ||
             RentFee.Text == "" 
             )
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    // Corrected column names in the insert query
                    string query = "insert into Rent ([RentID], [House Number], [Customer ID], [Phone Number], [Rent FEE]) values ('" + RentId.Text + "', '" + Hno.Text + "', '" + Custid.Text + "', '" + CustNu.Text + "', '" + RentFee.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully Rent");
                    conn.Close();
                    populate();

                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RentId.Text = dataGridView2.Rows[e.RowIndex].Cells["RentID"].Value.ToString();
            Hno.Text = dataGridView2.Rows[e.RowIndex].Cells["House Number"].Value.ToString();
            Custid.Text = dataGridView2.Rows[e.RowIndex].Cells["Customer ID"].Value.ToString();
            CustNu.Text = dataGridView2.Rows[e.RowIndex].Cells["Phone Number"].Value.ToString();
            RentFee.Text = dataGridView2.Rows[e.RowIndex].Cells["Rent FEE"].Value.ToString();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if 
             (
             RentId.Text == "" ||
             Hno.Text == "" ||
             Custid.Text == "" ||
              CustNu.Text ==""||
             RentFee.Text == ""
             )
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "update Rent set [House Number] = '" + Hno.Text + "', [Customer ID] = '" + Custid.Text + "', [Phone Number]= '" + CustNu.Text +  "', [Rent FEE] = '" + RentFee.Text +  "' where [RentID]= '" + RentId.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully ");
                    conn.Close();
                    populate();



                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (RentId.Text == "")
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from Rent where [RentID] ='" + RentId.Text + " '; ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }
    }
}
