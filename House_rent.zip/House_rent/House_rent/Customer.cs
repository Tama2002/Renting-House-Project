﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_rent
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database1.mdf"";Integrated Security=True");
        private void populate()
        {
            try
               {
                    using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database1.mdf"";Integrated Security=True"))
                    {
                    conn.Open();
                    string query = "select * from Customer";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    SqlCommandBuilder builder = new SqlCommandBuilder(da);
                    var ds = new DataSet();
                    da.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

        }
        private void Customer_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from Customer where ID ='" + txtUsername.Text + " '; ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtUsername.Text = dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString();
            txtFName.Text = dataGridView1.Rows[e.RowIndex].Cells["FirstName"].Value.ToString();
            txtLName.Text = dataGridView1.Rows[e.RowIndex].Cells["LastName"].Value.ToString();
            txtEmail.Text = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
            txtPassword.Text = dataGridView1.Rows[e.RowIndex].Cells["Password"].Value.ToString();
            txtCPassword.Text = dataGridView1.Rows[e.RowIndex].Cells["CPassword"].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (
             txtUsername.Text == "" ||
             txtFName.Text == "" ||
             txtLName.Text == "" ||
             txtEmail.Text == "" ||
             txtPassword.Text == "" ||
             txtCPassword.Text == ""
             )
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    // Corrected column names in the insert query
                    string query = "insert into Customer (ID, FirstName, LastName, Email, Password, CPassword) values ('" + txtUsername.Text + "', '" + txtFName.Text + "', '" + txtLName.Text + "', '" + txtEmail.Text + "', '" + txtPassword.Text + "', '" + txtCPassword.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Successfully Added");
                    conn.Close();
                    populate();

                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (txtUsername.Text == "" ||
             txtFName.Text == "" ||
             txtLName.Text == "" ||
             txtEmail.Text == "" ||
             txtPassword.Text == "" ||
             txtCPassword.Text == "")
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    // Corrected column names in the update query
                    string query = "update Customer set FirstName = '" + txtFName.Text + "', LastName = '" + txtLName.Text + "', Email = '" + txtEmail.Text + "', Password = '" + txtPassword.Text + "', CPassword = '" + txtCPassword.Text + "' where ID = '" + txtUsername.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully ");
                    conn.Close();
                    populate();

                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}