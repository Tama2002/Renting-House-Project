﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace House_rent
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database4.mdf"";Integrated Security=True");

        private void populate()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database4.mdf"";Integrated Security=True"))
                {
                    conn.Open();
                    string query = "select * from Admin";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm mainForm = new MainForm();
            mainForm.Show();
        }

        private void btnBackToLogin_Click(object sender, EventArgs e)
        {
            if (!this.txtEmail.Text.Contains('@') || !this.txtEmail.Text.Contains('.'))
            {
                MessageBox.Show("Please Enter A Valid Email", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (txtPassword.Text != txtCPassword.Text)
            {
                MessageBox.Show("Password doesn't match!", "Error");
                return;
            }
            if (txtFName.Text == "" ||
                txtLName.Text == "" ||
                txtUsername.Text == "" ||
                txtEmail.Text == "" ||
                txtPassword.Text == "" 
                )
            {
                MessageBox.Show("Fill the Box Properly!!");
            }
            else
            {
                if (!char.IsUpper(txtPassword.Text.First()))
                {
                    MessageBox.Show("Password must start with a capital letter and end with at least the last two symbols or digits !", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int passwordLength = txtPassword.Text.Length;
                if (passwordLength < 2 || !char.IsDigit(txtPassword.Text[passwordLength - 1]) || !char.IsDigit(txtPassword.Text[passwordLength - 2]))
                {
                    MessageBox.Show("Password must end with at least the last two symbols or digits ! ", "Invalid Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                try
                {
                    conn.Open();
                    string query = "insert into Admin (FirstName, LastName, Username, Email, Password, CPassword) values ('" + txtFName.Text + "', '" + txtLName.Text + "', '" + txtUsername.Text + "', '" + txtEmail.Text + "', '" + txtPassword.Text + "', '" + txtCPassword.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();

                    conn.Close();
                    populate();
                }
                catch(Exception ex) 
                {
                    MessageBox.Show(ex.Message);
                }
                finally 
                {
                    MessageBox.Show("Registration Sucessfully");
                }
                //this.Hide();
                //Login log = new Login();
                //log.Show();

            }

        }

        private void txtCPassword_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void Register_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (txtFName.Text == "" ||
                txtLName.Text == "" ||
                txtUsername.Text == "" ||
                txtEmail.Text == "" ||
                txtPassword.Text == ""
                )
            {
                MessageBox.Show("Fill the Box Properly!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    // Corrected column names in the update query
                    string query = "update Admin set FirstName = '" + txtFName.Text + "', LastName = '" + txtLName.Text + "', Email = '" + txtEmail.Text + "', Password = '" + txtPassword.Text + "', CPassword = '" + txtCPassword.Text + "' where Username = '" + txtUsername.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully ");
                    conn.Close();
                    populate();

                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                MessageBox.Show("MISSING INFORMATION");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from Admin where Username ='" + txtUsername.Text + " '; ";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Successfully");
                    conn.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txtFName.Text = dataGridView1.Rows[e.RowIndex].Cells["FirstName"].Value.ToString();
            txtLName.Text = dataGridView1.Rows[e.RowIndex].Cells["LastName"].Value.ToString();
            txtUsername.Text = dataGridView1.Rows[e.RowIndex].Cells["Username"].Value.ToString();
            txtEmail.Text = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
            txtPassword.Text = dataGridView1.Rows[e.RowIndex].Cells["Password"].Value.ToString();
            txtCPassword.Text = dataGridView1.Rows[e.RowIndex].Cells["CPassword"].Value.ToString();
        }
    }
    }

