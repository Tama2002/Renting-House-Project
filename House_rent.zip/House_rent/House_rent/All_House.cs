﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace House_rent
{
    public partial class All_House : Form
    {
        private SqlConnection conn;

        public All_House()
        {
            InitializeComponent();
            conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\Aiub classes\C#\Project\House_rent\House_rent\Database3.mdf"";Integrated Security=True");
        }
        private void PopulateDataGridView(string addressFilter = "")
        {
            try
            {
                conn.Open();
                string query = "select * from House";
                if (!string.IsNullOrEmpty(addressFilter))
                {
                    query += " WHERE Address LIKE @Address";
                }
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                if (!string.IsNullOrEmpty(addressFilter))
                {
                    da.SelectCommand.Parameters.AddWithValue("@Address", $"%{addressFilter}%");
                }
                var ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                conn.Close();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            All_House displayForm = new All_House();
            displayForm.ShowDialog();
        }

        private void All_House_Load(object sender, EventArgs e)
        {
            PopulateDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainForm2 mainForm = new MainForm2();
            mainForm.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rent rent = new Rent();
            rent.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PopulateDataGridView(txtAddress.Text);
        }
    }
}
