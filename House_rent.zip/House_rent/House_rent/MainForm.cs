﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace House_rent
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            House house = new House();
            house.Show();
            this.Hide();    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Rent_House rent_house = new Rent_House();
            rent_house.Show();
            this.Hide();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Register register = new Register();  
            register.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Total total = new Total();
            total.Show();
            this.Hide();
        }

  

        private void button8_Click(object sender, EventArgs e)
        {
            Logout logout = new Logout();
            logout.Show();
            this.Hide();
        }


        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            ComPayment comPayment = new ComPayment();
            comPayment.Show();
            this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
